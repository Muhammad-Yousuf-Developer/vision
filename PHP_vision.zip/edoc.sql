-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2022 at 11:33 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@admin.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `pid`, `apponum`, `scheduleid`, `appodate`) VALUES
(1, 1, 1, 1, '2022-06-03'),
(2, 1, 1, 9, '2022-09-15'),
(3, 4, 2, 9, '2022-09-15'),
(6, 6, 1, 11, '2022-09-24'),
(12, 8, 3, 12, '2022-09-24'),
(14, 9, 3, 12, '2022-09-24'),
(15, 9, 1, 14, '2022-09-24'),
(16, 8, 2, 14, '2022-09-24');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `docnic` varchar(15) DEFAULT NULL,
  `doctel` varchar(15) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docid`, `docemail`, `docname`, `docpassword`, `docnic`, `doctel`, `specialties`) VALUES
(1, 'doctor@gmail.com', 'Test Doctor', '202cb962ac59075b964b07152d234b70', '000000000', '0110000000', 1),
(2, 'hibaaaaa@gmail.com', 'Hiba baber', '202cb962ac59075b964b07152d234b70', '000', '03352068925', 14),
(3, 'asd@saf', 'maria ahmed khan', '202cb962ac59075b964b07152d234b70', '132123', '1231', 1),
(4, 'zeeshanshahid@ok.com', 'maria ahmed khan', '202cb962ac59075b964b07152d234b70', '42101 123456 3', '09131321231', 1),
(5, 'ad@gmail.com', 'samina begam ', '123', '42101 123456 7', '1231', 15),
(7, 'zeeshan@s.com', 'maria ahmed khansss', 'c20ad4d76fe97759aa27a0c99bff6710', '42101 123456 7', '1231', 1),
(8, 'daniak5@gmail.com', 'maria ahmed khanaa', '202cb962ac59075b964b07152d234b70', '42101 123456 3', '1231', 18),
(9, 'yousuf@gmail.com', 'yousuf', '202cb962ac59075b964b07152d234b70', '42101 123456 3', '09131321231', 5),
(10, 'anas2@gmail.com', 'anas', '202cb962ac59075b964b07152d234b70', '4210112531241', '09131321231', 9),
(11, 'mohsin@gmail.com', 'sir mohsin', 'c6f057b86584942e415435ffb1fa93d4', '42101 123456 7', '09131321231', 5);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pnic` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pnic`, `pdob`, `ptel`) VALUES
(1, 'patient@gmail.com', 'Test Patient', '202cb962ac59075b964b07152d234b70', 'Sri Lanka', '0000000000', '2000-01-01', '0120000000'),
(2, 'emhashenudara@gmail.com', 'Hashen Udara', '202cb962ac59075b964b07152d234b70', 'Sri Lanka', '0110000000', '2022-06-03', '0700000000'),
(3, 'hina@gmail.com', ' ', '202cb962ac59075b964b07152d234b70', '', '', '0000-00-00', '0744489985'),
(4, 'hibashah961@gmail.com', 'Hiba baber', '202cb962ac59075b964b07152d234b70', 'R169 sector 15 a 5 bufferzone karachi', '000', '0004-04-04', '0748551555'),
(5, 'anas@gmail.com', 'anas hameed', '202cb962ac59075b964b07152d234b70', 'l853', '4210112531242', '2022-09-22', '0712345678'),
(6, 'xyz@gmail.com', 'sasass sdsss', '202cb962ac59075b964b07152d234b70', 'G8xLR8DAr6XYK1e5EvBWEbCtjLXyg25n9wvJ1feSwtR6', '42101 123456 7', '2022-09-14', '0712345678'),
(7, 'imad@gmail.com', 'sir imad', '202cb962ac59075b964b07152d234b70', 'nazimabad', '42101 123456 3', '2022-09-08', '0712345678'),
(8, 'umar@gmail.com', 'umar ali', '202cb962ac59075b964b07152d234b70', 'nagan', '4210112531241', '2022-09-23', '0712345678'),
(9, 'hassan@gmail.com', 'hassan hameed', '202cb962ac59075b964b07152d234b70', 'bufferzone', '4210112531241', '2022-09-24', '0712345678');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `docid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `nop` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `docid`, `title`, `scheduledate`, `scheduletime`, `nop`) VALUES
(2, '1', '1', '2022-06-10', '20:36:00', 1),
(3, '1', '12', '2022-06-10', '20:33:00', 1),
(4, '1', '1', '2022-06-10', '12:32:00', 1),
(9, '2', 'hhhh', '2022-09-20', '05:30:00', 0),
(6, '1', '12', '2022-06-10', '20:35:00', 1),
(7, '1', '1', '2022-06-24', '20:36:00', 1),
(8, '1', '12', '2022-06-10', '13:33:00', 1),
(10, '7', 'exampl', '2022-09-28', '02:43:00', 3),
(11, '9', 'qwerty', '2022-09-29', '16:09:00', 3),
(12, '11', 'cardio', '2022-09-28', '17:04:00', 3),
(13, '10', 'dentist', '2022-09-28', '15:48:00', 5),
(14, '10', 'dentist', '2022-09-24', '16:06:00', 5),
(15, '2', 'sicolo', '2022-09-24', '14:25:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `sname`) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clinical biology'),
(8, 'Clinical chemistry'),
(9, 'Clinical neurophysiology'),
(10, 'Clinical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology');

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@admin.com', 'a'),
('doctor@gmail.com', 'd'),
('patient@gmail.com', 'p'),
('emhashenudara@gmail.com', 'p'),
('hina@gmail.com', 'p'),
('hibashah961@gmail.com', 'p'),
('hibaaaaa@gmail.com', 'd'),
('asd@saf', 'p'),
('zeeshanshahid@ok.com', 'd'),
('ad@gmail.com', 'd'),
('zeeshan@s.com', 'd'),
('daniak5@gmail.com', 'd'),
('anas@gmail.com', 'p'),
('xyz@gmail.com', 'p'),
('yousuf@gmail.com', 'd'),
('anas2@gmail.com', 'd'),
('imad@gmail.com', 'p'),
('mohsin@gmail.com', 'd'),
('umar@gmail.com', 'p'),
('hassan@gmail.com', 'p');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docid`),
  ADD KEY `specialties` (`specialties`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `docid` (`docid`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
