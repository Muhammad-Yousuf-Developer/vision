<head>
		<meta charset="utf-8">
		<title>Doccure</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
		<!-- Favicons -->
		<!-- <link href="assets/img/favicon.png" rel="icon"> -->
		
		<!-- Bootstrap CSS -->  
		<!-- <link rel="stylesheet" href="assets/css/bootstrap.min.css"> -->
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Main CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
	</head>
<!-- Header -->
<header class="header">
    <nav class="navbar navbar-expand-lg header-nav">
        <div class="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
                <span class="bar-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </a>
            <a href="index-2.php" class="navbar-brand logo">
                <img src="assets/img/logo.png" class="img-fluid" alt="Logo">
            </a>
        </div>
        <div class="main-menu-wrapper">
            <div class="menu-header">
                <a href="index-2.php" class="menu-logo">
                    <img src="assets/img/logo.png" class="img-fluid" alt="Logo">
                </a>
                <a id="menu_close" class="menu-close" href="javascript:void(0);">
                    <i class="fas fa-times"></i>
                </a>
            </div>
            <ul class="main-nav">
                <li>
                 <b>   <a href="../index.php">Back To Website</a><b>
                </li>
                <?php 
            if(isset($_SESSION["user"]))
            {
                ?>
               
              
              
                <?php		
										}
                                        else{
                                            ?>
                                           
                                        <?php
                                        }
									?>
                                      <?php 
            if(isset($_SESSION["user"]))
            {
                ?>
               
                <?php		
										}
                                        else{
                                            ?>
                                            <li>
                    <a href="admin/index.php" target="blank">Admin</a>
                </li>
                <li>
                    <a href="doctor/index.php" target="blank">Doctor</a>
                </li>
                                        <?php
                                        }
									?>
                <li class="login-link">
                    <a href="login.php">Login / Signup</a>
                </li>
            </ul>
        </div>
        <ul class="nav header-navbar-rht">
            <li class="nav-item contact-item">
                <div class="header-contact-img">
                    <i class="far fa-hospital"></i>							
                </div>
                <div class="header-contact-detail">
                    <p class="contact-header">Contact</p>
                    <p class="contact-info-header"> +92 335 4520235</p>
                </div>
            </li>
            <?php 
            if(isset($_SESSION["user"]))
            {
                ?>
<!--User Menu -->
<!-- <li class="nav-item dropdown has-arrow logged-item">
							<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
								<span class="user-img">
									<img class="rounded-circle" src="assets/img/patients/patient.png" width="31" alt="Darren Elder">
								</span>
                               
							</a>
							<div class="dropdown-menu dropdown-menu-right">
								<div class="user-header">
									<div class="avatar avatar-sm">
										<img src="assets/img/patients/patient.png" alt="User Image" class="avatar-img rounded-circle">
									</div>
									<div class="user-text">
                                    <h6><?php echo $_SESSION["user"]; ?></h6>
									</div>
								</div>
								<a class="dropdown-item" href="patient/index.php">Dashboard</a>
								<a class="dropdown-item" href="logout.php">Logout</a>
							</div>
                            <?php		
										}
                                        else{
                                            ?>
                                            <li class="nav-item">
                                            <a class="nav-link header-login" href="login.php">login / Signup </a>
                                        </li>
                                        <?php
                                        }
									?>
						      </li> -->
<!--User Menu -->
        </ul>
    </nav>
</header>
<!-- /Header -->
