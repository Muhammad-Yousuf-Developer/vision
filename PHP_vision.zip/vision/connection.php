<?php

$ServerName = "localhost";
$ServerUser = "root";
$ServerPassword = "";
$DatabaseName = "edoc";


$database = mysqli_connect($ServerName,$ServerUser,$ServerPassword,$DatabaseName);




     if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>